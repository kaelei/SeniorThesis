<!-- Author: Kaelei Lewis-->
<?php


    ?>
    
    <form action="thesisList.php" method="post"> 
	<div>
        Item Name: <input type="text" name="item" value="itemName" /> <br />	

    
        Price: <input type="text" name="price"><br> 

	</div>
        <input class="listBtn" type="submit" name="list" value="List"/>

 
</form>
<?php


?>

