<?php

$con = mysqli_connect("localhost", "root", "", "senior_thesis");

if (mysqli_connect_errno()) {
    echo "Failed to Connect" . mysqli_connect_error();
    exit();
}
$item=$_POST["item"];
$price=$_POST["price"];

        
        $sql = "INSERT INTO listing (user_id, item_name, item_price, img_id)
        VALUES (1, '$item', $price, 1)";
        if ($con->query($sql) === TRUE) {
            echo "New record created successfully";
            echo "<br>". $item . ": $" . $price;
            ?>
            <br>
            <a class="button" href="thesis.php" target="_blank">New Listing</a>
             <a class="button" href="browse.php" target="_blank">Browse Listings</a>
             <?php
            } else {
                echo "Error: Retry connection and list again:"
                ?>
                <br>
                <a class="button" href="thesis.php" target="_blank">New Listing</a>
                <?php
            }
        
  ?>